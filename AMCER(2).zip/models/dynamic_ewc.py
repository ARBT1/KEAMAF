import torch
import torch.nn as nn
import torch.optim as optim
from collections import defaultdict
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import json
from transformers import BertTokenizer


class DynamicEWC:
    """
    动态重要性加权的弹性权重巩固(Dynamic Elastic Weight Consolidation)
    根据材料领域实体类型动态调整Fisher信息权重，对关键参数给予更高保护
    """
    
    def __init__(self, model: nn.Module, lambda_base: float = 1e3, 
                 entity_weight_config: Optional[Dict[str, float]] = None):
        """
        初始化动态EWC
        
        Args:
            model: 需要保护的神经网络模型
            lambda_base: 基础正则化强度
            entity_weight_config: 实体类型权重配置
        """
        self.model = model
        self.lambda_base = lambda_base
        self.fisher = {}
        self.opt_params = {}
        self.entity_freq = defaultdict(int)
        self.relation_freq = defaultdict(int)
        self.task_history = []
        
        # 材料领域实体权重配置
        self.entity_weight_config = entity_weight_config or self._get_default_entity_weights()
        
        # 参数重要性映射
        self.param_importance_map = self._build_param_importance_map()
        
        # 设备配置
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    def _get_default_entity_weights(self) -> Dict[str, float]:
        """
        获取默认的材料领域实体权重配置
        
        Returns:
            Dict[str, float]: 实体类型权重字典
        """
        return {
            # 成分相关实体 - 高权重
            "Element": 2.5,  # 元素
            "Comp": 2.0,     # 成分
            "Phase": 2.2,    # 相
            
            # 工艺参数 - 最高权重
            "Exp": 3.0,      # 实验/工艺
            "Par_n": 2.8,    # 参数名
            "Par_v": 2.8,    # 参数值
            
            # 性能指标 - 高权重
            "Test_n": 2.3,   # 测试名称
            "Test_v": 2.3,   # 测试值
            "Property": 2.1, # 性能属性
            
            # 其他实体 - 标准权重
            "Material": 1.5, # 材料
            "Method": 1.2,   # 方法
            "Equipment": 1.0 # 设备
        }
    
    def _build_param_importance_map(self) -> Dict[str, float]:
        """
        构建参数重要性映射
        
        Returns:
            Dict[str, float]: 参数重要性映射字典
        """
        importance_map = {}
        
        # 嵌入层参数 - 高重要性
        embedding_keywords = ['embedding', 'embed', 'word_embeddings']
        
        # 注意力层参数 - 中等重要性
        attention_keywords = ['attention', 'attn', 'mha', 'multihead']
        
        # 分类层参数 - 高重要性
        classifier_keywords = ['classifier', 'linear', 'relation_linear', 'project_matrix']
        
        # BERT层参数 - 中等重要性
        bert_keywords = ['bert', 'encoder', 'layer']
        
        return {
            'embedding': 2.5,
            'attention': 1.8,
            'classifier': 2.2,
            'bert': 1.5,
            'default': 1.0
        }
    
    def update_frequency_statistics(self, task_data: List[Dict[str, Any]]) -> None:
        """
        更新实体和关系频率统计
        
        Args:
            task_data: 任务数据列表
        """
        print(f"更新频率统计，处理 {len(task_data)} 个样本")
        
        for sample in task_data:
            # 兼容不同的数据格式
            if 'spo_list' in sample:
                triples = sample['spo_list']
            elif 'triples' in sample:
                triples = sample['triples']
            else:
                continue
            
            for triple in triples:
                if isinstance(triple, dict):
                    # 字典格式: {'head': ..., 'relation': ..., 'tail': ...}
                    head_type = self._extract_entity_type(triple.get('head', ''))
                    tail_type = self._extract_entity_type(triple.get('tail', ''))
                    relation = triple.get('relation', '')
                elif isinstance(triple, list) and len(triple) >= 3:
                    # 列表格式: [head, relation, tail]
                    head_type = self._extract_entity_type(str(triple[0]))
                    tail_type = self._extract_entity_type(str(triple[2]))
                    relation = str(triple[1])
                else:
                    continue
                
                # 更新频率统计
                if head_type:
                    self.entity_freq[head_type] += 1
                if tail_type:
                    self.entity_freq[tail_type] += 1
                if relation:
                    self.relation_freq[relation] += 1
        
        print(f"实体频率统计: {dict(self.entity_freq)}")
        print(f"关系频率统计: {dict(self.relation_freq)}")
    
    def _extract_entity_type(self, entity_text: str) -> Optional[str]:
        """
        从实体文本中提取实体类型
        
        Args:
            entity_text: 实体文本
            
        Returns:
            Optional[str]: 实体类型
        """
        if not entity_text:
            return None
        
        entity_text = entity_text.lower()
        
        # 元素类型检测
        element_keywords = ['al', 'mg', 'si', 'fe', 'ni', 'cu', 'zn', '铝', '镁', '硅', '铁', '镍', '铜', '锌']
        if any(keyword in entity_text for keyword in element_keywords):
            return "Element"
        
        # 成分类型检测
        comp_keywords = ['合金', 'alloy', '成分', 'composition', 'wt%', 'at%']
        if any(keyword in entity_text for keyword in comp_keywords):
            return "Comp"
        
        # 相类型检测
        phase_keywords = ['相', 'phase', 'mg2si', 'al3ni', 'fe3c']
        if any(keyword in entity_text for keyword in phase_keywords):
            return "Phase"
        
        # 工艺类型检测
        exp_keywords = ['热处理', '固溶', '时效', '退火', '淬火', 'heat treatment', 'annealing']
        if any(keyword in entity_text for keyword in exp_keywords):
            return "Exp"
        
        # 参数名检测
        par_n_keywords = ['温度', '压力', '时间', '速度', 'temperature', 'pressure', 'time', 'speed']
        if any(keyword in entity_text for keyword in par_n_keywords):
            return "Par_n"
        
        # 参数值检测
        if any(char.isdigit() for char in entity_text) and any(unit in entity_text for unit in ['°c', 'mpa', 'h', 'min', 'mm/min']):
            return "Par_v"
        
        # 测试名检测
        test_n_keywords = ['硬度', '强度', '延伸率', '韧性', 'hardness', 'strength', 'elongation']
        if any(keyword in entity_text for keyword in test_n_keywords):
            return "Test_n"
        
        # 测试值检测
        if any(char.isdigit() for char in entity_text) and any(unit in entity_text for unit in ['hv', 'mpa', '%', 'j/cm²']):
            return "Test_v"
        
        return "Material"  # 默认为材料类型
    
    def calculate_dynamic_fisher(self, dataloader, tokenizer: Optional[BertTokenizer] = None) -> None:
        """
        计算动态加权Fisher信息矩阵
        
        Args:
            dataloader: 数据加载器
            tokenizer: 分词器（可选）
        """
        print("开始计算动态Fisher信息矩阵...")
        
        self.model.train()
        optimizer = optim.Adam(self.model.parameters(), lr=1e-5)
        
        # 初始化Fisher信息矩阵
        fisher_dict = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                fisher_dict[name] = torch.zeros_like(param.data)
        
        sample_count = 0
        
        # 计算Fisher信息
        for batch_idx, batch in enumerate(dataloader):
            if batch_idx >= 100:  # 限制计算样本数量以提高效率
                break
            
            try:
                # 前向传播
                if hasattr(self.model, 'forward'):
                    outputs = self.model(batch, train=True)
                else:
                    continue
                
                # 计算损失（使用交叉熵损失）
                if 'matrix' in batch:
                    target = batch['matrix'].to(self.device)
                    loss_mask = batch.get('loss_mask', torch.ones_like(target)).to(self.device)
                    
                    # 计算损失
                    loss_fn = nn.CrossEntropyLoss(reduction='none')
                    loss = loss_fn(outputs.view(-1, outputs.size(-1)), target.view(-1))
                    loss = torch.sum(loss * loss_mask.view(-1)) / torch.sum(loss_mask)
                else:
                    # 如果没有目标，使用输出的均值作为损失
                    loss = outputs.mean()
                
                # 反向传播
                optimizer.zero_grad()
                loss.backward()
                
                # 累积Fisher信息
                for name, param in self.model.named_parameters():
                    if param.grad is not None and name in fisher_dict:
                        fisher_dict[name] += param.grad.data.clone().pow(2)
                
                sample_count += 1
                
            except Exception as e:
                print(f"计算Fisher信息时出错 (batch {batch_idx}): {e}")
                continue
        
        if sample_count == 0:
            print("警告: 没有成功处理任何样本")
            return
        
        # 平均化Fisher信息
        for name in fisher_dict:
            fisher_dict[name] /= sample_count
        
        # 应用动态权重
        self.fisher = self._apply_dynamic_weights(fisher_dict)
        
        # 保存当前参数
        self.opt_params = {n: p.data.clone() for n, p in self.model.named_parameters()}
        
        print(f"Fisher信息计算完成，处理了 {sample_count} 个样本")
    
    def _apply_dynamic_weights(self, fisher_dict: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        应用动态权重到Fisher信息矩阵
        
        Args:
            fisher_dict: 原始Fisher信息字典
            
        Returns:
            Dict[str, torch.Tensor]: 加权后的Fisher信息字典
        """
        weighted_fisher = {}
        
        for name, fisher_value in fisher_dict.items():
            # 获取参数类型权重
            param_weight = self._get_param_weight(name)
            
            # 获取实体频率权重
            entity_weight = self._get_entity_frequency_weight(name)
            
            # 综合权重
            total_weight = param_weight * entity_weight
            
            # 应用权重
            weighted_fisher[name] = fisher_value * total_weight
            
            print(f"参数 {name}: 参数权重={param_weight:.2f}, 实体权重={entity_weight:.2f}, 总权重={total_weight:.2f}")
        
        return weighted_fisher
    
    def _get_param_weight(self, param_name: str) -> float:
        """
        获取参数权重
        
        Args:
            param_name: 参数名称
            
        Returns:
            float: 参数权重
        """
        param_name_lower = param_name.lower()
        
        for keyword, weight in self.param_importance_map.items():
            if keyword != 'default' and keyword in param_name_lower:
                return weight
        
        return self.param_importance_map['default']
    
    def _get_entity_frequency_weight(self, param_name: str) -> float:
        """
        根据实体频率获取权重
        
        Args:
            param_name: 参数名称
            
        Returns:
            float: 实体频率权重
        """
        # 如果是实体嵌入相关参数，根据实体频率调整权重
        if 'embedding' in param_name.lower() or 'embed' in param_name.lower():
            # 计算平均实体频率
            if self.entity_freq:
                avg_freq = sum(self.entity_freq.values()) / len(self.entity_freq)
                # 频率越高，权重越大
                return 1.0 + min(avg_freq / 100.0, 2.0)  # 最大增加2倍权重
        
        return 1.0
    
    def calculate_ewc_penalty(self) -> torch.Tensor:
        """
        计算EWC惩罚项
        
        Returns:
            torch.Tensor: EWC惩罚损失
        """
        if not self.fisher or not self.opt_params:
            return torch.tensor(0.0, device=self.device)
        
        penalty = torch.tensor(0.0, device=self.device)
        
        for name, param in self.model.named_parameters():
            if name in self.fisher and name in self.opt_params:
                # 计算参数变化的惩罚
                param_penalty = self.fisher[name] * (param - self.opt_params[name]).pow(2)
                penalty += param_penalty.sum()
        
        return self.lambda_base * penalty
    
    def update_task_history(self, task_info: Dict[str, Any]) -> None:
        """
        更新任务历史记录
        
        Args:
            task_info: 任务信息字典
        """
        self.task_history.append({
            'task_id': len(self.task_history),
            'entity_freq': dict(self.entity_freq),
            'relation_freq': dict(self.relation_freq),
            'fisher_computed': len(self.fisher) > 0,
            **task_info
        })
    
    def get_importance_statistics(self) -> Dict[str, Any]:
        """
        获取重要性统计信息
        
        Returns:
            Dict[str, Any]: 重要性统计信息
        """
        stats = {
            'entity_frequencies': dict(self.entity_freq),
            'relation_frequencies': dict(self.relation_freq),
            'entity_weights': self.entity_weight_config,
            'param_importance': self.param_importance_map,
            'task_count': len(self.task_history),
            'fisher_params': list(self.fisher.keys()) if self.fisher else []
        }
        
        return stats
    
    def save_ewc_state(self, filepath: str) -> None:
        """
        保存EWC状态
        
        Args:
            filepath: 保存路径
        """
        state = {
            'fisher': {k: v.cpu() for k, v in self.fisher.items()},
            'opt_params': {k: v.cpu() for k, v in self.opt_params.items()},
            'entity_freq': dict(self.entity_freq),
            'relation_freq': dict(self.relation_freq),
            'task_history': self.task_history,
            'lambda_base': self.lambda_base,
            'entity_weight_config': self.entity_weight_config
        }
        
        torch.save(state, filepath)
        print(f"EWC状态已保存到: {filepath}")
    
    def load_ewc_state(self, filepath: str) -> None:
        """
        加载EWC状态
        
        Args:
            filepath: 加载路径
        """
        try:
            state = torch.load(filepath, map_location=self.device)
            
            self.fisher = {k: v.to(self.device) for k, v in state['fisher'].items()}
            self.opt_params = {k: v.to(self.device) for k, v in state['opt_params'].items()}
            self.entity_freq = defaultdict(int, state['entity_freq'])
            self.relation_freq = defaultdict(int, state['relation_freq'])
            self.task_history = state['task_history']
            self.lambda_base = state['lambda_base']
            self.entity_weight_config = state['entity_weight_config']
            
            print(f"EWC状态已从 {filepath} 加载")
            
        except Exception as e:
            print(f"加载EWC状态失败: {e}")


class EWCTrainer:
    """
    集成EWC的训练器
    """
    
    def __init__(self, model: nn.Module, ewc: DynamicEWC, base_optimizer: optim.Optimizer):
        """
        初始化EWC训练器
        
        Args:
            model: 模型
            ewc: 动态EWC实例
            base_optimizer: 基础优化器
        """
        self.model = model
        self.ewc = ewc
        self.base_optimizer = base_optimizer
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    def train_step(self, batch: Dict[str, Any], base_loss_fn) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        执行一步训练，包含EWC惩罚
        
        Args:
            batch: 训练批次数据
            base_loss_fn: 基础损失函数
            
        Returns:
            Tuple[torch.Tensor, torch.Tensor, torch.Tensor]: (总损失, 基础损失, EWC惩罚)
        """
        # 前向传播
        outputs = self.model(batch, train=True)
        
        # 计算基础损失
        if 'matrix' in batch:
            target = batch['matrix'].to(self.device)
            loss_mask = batch.get('loss_mask', torch.ones_like(target)).to(self.device)
            base_loss = base_loss_fn(outputs, target, loss_mask)
        else:
            base_loss = outputs.mean()  # 默认损失
        
        # 计算EWC惩罚
        ewc_penalty = self.ewc.calculate_ewc_penalty()
        
        # 总损失
        total_loss = base_loss + ewc_penalty
        
        # 反向传播
        self.base_optimizer.zero_grad()
        total_loss.backward()
        self.base_optimizer.step()
        
        return total_loss, base_loss, ewc_penalty


if __name__ == "__main__":
    # 测试代码
    print("测试动态EWC模块...")
    
    # 创建一个简单的测试模型
    class TestModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.embedding = nn.Embedding(1000, 128)
            self.linear = nn.Linear(128, 64)
            self.classifier = nn.Linear(64, 10)
        
        def forward(self, x, train=True):
            if isinstance(x, dict) and 'input_ids' in x:
                x = x['input_ids']
            x = self.embedding(x)
            x = x.mean(dim=1)  # 简单平均池化
            x = self.linear(x)
            return self.classifier(x)
    
    # 创建测试模型和EWC
    model = TestModel()
    ewc = DynamicEWC(model, lambda_base=1000)
    
    # 测试实体类型提取
    test_entities = ["铝合金", "Mg2Si相", "固溶处理", "温度500°C", "硬度200HV"]
    for entity in test_entities:
        entity_type = ewc._extract_entity_type(entity)
        print(f"实体: {entity} -> 类型: {entity_type}")
    
    # 测试频率统计
    test_data = [
        {
            'text': '铝合金在500°C下进行固溶处理',
            'spo_list': [
                ['铝合金', 'Exp-Par_v', '500°C'],
                ['固溶处理', 'Par_n-Par_v', '温度']
            ]
        }
    ]
    
    ewc.update_frequency_statistics(test_data)
    
    # 获取统计信息
    stats = ewc.get_importance_statistics()
    print("\n重要性统计信息:")
    for key, value in stats.items():
        print(f"{key}: {value}")