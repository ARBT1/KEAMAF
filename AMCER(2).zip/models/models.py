import torch
import torch.nn as nn
from torch.autograd import Variable
from .lebert import LEBertModel
from typing import Dict, List, Tuple, Optional, Any
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# from config import Configargs
from config.config import Configargs

class OneRel(nn.Module):
    """
    OneRel模型：基于LEBert的关系抽取模型
    实现端到端的实体关系联合抽取
    """
    
    def __init__(self, config):
        """
        初始化OneRel模型
        
        Args:
            config: 模型配置对象，包含模型参数和超参数
        """
        super(OneRel, self).__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.configargs = Configargs()
        self.use_cuda = True
        
        try:
            # 初始化词嵌入层
            self.word_embeddings = nn.Embedding(config.word_vocab_size, config.word_embed_dim).to(self.device)
            
            # 初始化LEBert编码器
            self.bert = LEBertModel.from_pretrained(pretrained_model_name_or_path=self.configargs.bert_path).to(self.device)
            logger.info(f"成功加载LEBert模型: {self.configargs.bert_path}")
            
            # 多头注意力机制
            self.mha = nn.MultiheadAttention(self.configargs.bert_dim, num_heads=12).to(self.device)
            
            # 线性变换层
            self.linear1 = nn.Linear(self.configargs.bert_dim * 2, self.configargs.bert_dim).to(self.device)
            self.relation_linear = nn.Linear(self.configargs.bert_dim * 3, self.configargs.num_rel * self.configargs.tag_size).to(self.device)
            self.project_matrix = nn.Linear(self.configargs.bert_dim * 2, self.configargs.bert_dim * 3).to(self.device)
            
            # Dropout层
            self.dropout = nn.Dropout(0.2).to(self.device)
            self.dropout_2 = nn.Dropout(0.1).to(self.device)
            
            # 激活函数
            self.activation = nn.ReLU().to(self.device)
            
            # 初始化权重
            self._init_weights()
            
            logger.info(f"OneRel模型初始化完成，参数数量: {self.count_parameters()}")
            
        except Exception as e:
            logger.error(f"OneRel模型初始化失败: {e}")
            raise
    
    def _init_weights(self) -> None:
        """
        初始化模型权重
        """
        for module in [self.linear1, self.relation_linear, self.project_matrix]:
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
    
    def count_parameters(self) -> int:
        """
        计算模型参数数量
        
        Returns:
            int: 可训练参数总数
        """
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def get_encoded_text(self, input_ids: torch.Tensor, mask: torch.Tensor, word_ids: torch.Tensor, word_mask: torch.Tensor) -> torch.Tensor:
        """
        使用LEBert编码输入文本
        
        Args:
            input_ids: 输入token的ID序列 [batch_size, seq_len]
            mask: 注意力掩码 [batch_size, seq_len]
            word_ids: 词级别的ID序列 [batch_size, word_len]
            word_mask: 词级别的掩码 [batch_size, word_len]
            
        Returns:
            torch.Tensor: LEBert编码后的文本表示
        """
        try:
            word_embeddings = self.word_embeddings(word_ids)
            bert_encoded_text = self.bert(input_ids=input_ids, attention_mask=mask, word_embeddings=word_embeddings, word_mask=word_mask)
            return bert_encoded_text
        except Exception as e:
            logger.error(f"文本编码过程中出错: {e}")
            raise

    def rand_init_hidden(self, batch_size):
        if self.use_cuda:
            return Variable(
                torch.randn(2 * self.configargs.rnn_layers, batch_size, self.configargs.hidden_dim)).cuda(), Variable(
                torch.randn(2 * self.configargs.rnn_layers, batch_size, self.configargs.hidden_dim)).cuda()
        else:
            return Variable(
                torch.randn(2 * self.configargs.rnn_layers, batch_size, self.configargs.hidden_dim)), Variable(
                torch.randn(2 * self.configargs.rnn_layers, batch_size, self.configargs.hidden_dim))

    def get_triple_score(self, sequence_output: torch.Tensor, train: bool) -> torch.Tensor:
        """
        计算三元组分数（带多头注意力机制）
        
        Args:
            sequence_output: 序列编码输出 [batch_size, seq_len, bert_dim]
            train: 是否为训练模式
            
        Returns:
            torch.Tensor: 三元组分数矩阵
        """
        try:
            batch_size, seq_len, bert_dim = sequence_output.size()
            
            # 应用多头注意力机制
            sequence_output, attn_output_weights1 = self.mha(sequence_output, sequence_output, sequence_output)

            # 构建头实体表示
            head_rep = sequence_output.unsqueeze(dim=2).expand(batch_size, seq_len, seq_len, bert_dim).reshape(batch_size, seq_len * seq_len, bert_dim)
            # 构建尾实体表示
            tail_rep = sequence_output.repeat(1, seq_len, 1)
            
            # 拼接头尾实体表示 [batch_size, seq_len*seq_len, bert_dim * 2]
            entity_pair = torch.cat([head_rep, tail_rep], dim=-1)

            # 投影到更高维空间 [batch_size, seq_len*seq_len, bert_dim * 3]
            entity_pair = self.project_matrix(entity_pair)
            entity_pair = self.dropout_2(entity_pair)
            entity_pair = self.activation(entity_pair)

            # 计算关系分数 [batch_size, seq_len*seq_len, num_rel*tag_size]
            matrix_score = self.relation_linear(entity_pair).reshape(batch_size, seq_len, seq_len, self.configargs.num_rel, self.configargs.tag_size)
            
            if train:
                return matrix_score.permute(0, 4, 3, 1, 2)
            else:
                return matrix_score.argmax(dim=-1).permute(0, 3, 1, 2)
                
        except Exception as e:
            logger.error(f"计算三元组分数时出错: {e}")
            raise

    def get_triple_score_test(self, sequence_output: torch.Tensor, train: bool) -> torch.Tensor:
        """
        计算三元组分数（测试版本，不使用多头注意力）
        
        Args:
            sequence_output: 序列编码输出 [batch_size, seq_len, bert_dim]
            train: 是否为训练模式
            
        Returns:
            torch.Tensor: 三元组分数矩阵
        """
        try:
            batch_size, seq_len, bert_dim = sequence_output.size()
            
            # 构建头实体表示
            head_rep = sequence_output.unsqueeze(dim=2).expand(batch_size, seq_len, seq_len, bert_dim).reshape(batch_size, seq_len * seq_len, bert_dim)
            # 构建尾实体表示
            tail_rep = sequence_output.repeat(1, seq_len, 1)
            
            # 拼接头尾实体表示 [batch_size, seq_len*seq_len, bert_dim * 2]
            entity_pair = torch.cat([head_rep, tail_rep], dim=-1)

            # 投影到更高维空间 [batch_size, seq_len*seq_len, bert_dim * 3]
            entity_pair = self.project_matrix(entity_pair)
            entity_pair = self.dropout_2(entity_pair)
            entity_pair = self.activation(entity_pair)

            # 计算关系分数 [batch_size, seq_len*seq_len, num_rel*tag_size]
            matrix_score = self.relation_linear(entity_pair).reshape(batch_size, seq_len, seq_len, self.configargs.num_rel, self.configargs.tag_size)
            
            if train:
                return matrix_score.permute(0, 4, 3, 1, 2)
            else:
                return matrix_score.argmax(dim=-1).permute(0, 3, 1, 2)
                
        except Exception as e:
            logger.error(f"计算三元组分数（测试版本）时出错: {e}")
            raise

    def forward(self, data: Dict[str, torch.Tensor], train: bool = True) -> torch.Tensor:
        """
        模型前向传播
        
        Args:
            data: 批次数据字典，包含input_ids, attention_mask, word_ids, word_mask
            train: 是否为训练模式
            
        Returns:
            torch.Tensor: 三元组分数矩阵
        """
        try:
            # 验证输入数据
            required_keys = ["input_ids", "attention_mask", "word_ids", "word_mask"]
            for key in required_keys:
                if key not in data:
                    raise ValueError(f"批次数据必须包含{key}")
            
            # 将数据移动到设备
            input_ids = data["input_ids"].to(self.device)
            attention_mask = data["attention_mask"].to(self.device)
            word_ids = data["word_ids"].to(self.device)
            word_mask = data["word_mask"].to(self.device)
            
            # 编码文本
            bert_encoded_text = self.get_encoded_text(input_ids, attention_mask, word_ids, word_mask)
            
            # 应用dropout
            sequence_output = self.dropout(bert_encoded_text[0])
            
            # 计算三元组分数
            matrix_score = self.get_triple_score_test(sequence_output, train)
            
            return matrix_score
            
        except Exception as e:
            logger.error(f"模型前向传播出错: {e}")
            raise