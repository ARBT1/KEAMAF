import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict, deque
import random
import json
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import pickle
import os


class SemanticReplayBuffer:
    """
    语义导向的经验回放缓冲区
    基于材料领域语义相似性进行智能样本选择和回放
    """
    
    def __init__(self, max_size: int = 10000, semantic_threshold: float = 0.7,
                 diversity_weight: float = 0.3, importance_weight: float = 0.4):
        """
        初始化语义回放缓冲区
        
        Args:
            max_size: 缓冲区最大容量
            semantic_threshold: 语义相似性阈值
            diversity_weight: 多样性权重
            importance_weight: 重要性权重
        """
        self.max_size = max_size
        self.semantic_threshold = semantic_threshold
        self.diversity_weight = diversity_weight
        self.importance_weight = importance_weight
        
        # 存储结构
        self.buffer = deque(maxlen=max_size)
        self.semantic_embeddings = []
        self.importance_scores = []
        self.entity_type_counts = defaultdict(int)
        self.relation_type_counts = defaultdict(int)
        
        # 语义分析工具
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=1000,
            stop_words=None,
            ngram_range=(1, 2)
        )
        self.is_fitted = False
        
        # 材料领域关键词权重
        self.domain_keywords = self._get_domain_keywords()
        
        # 统计信息
        self.replay_stats = {
            'total_added': 0,
            'total_replayed': 0,
            'semantic_matches': 0,
            'diversity_selections': 0
        }
    
    def _get_domain_keywords(self) -> Dict[str, float]:
        """
        获取材料领域关键词及其权重
        
        Returns:
            Dict[str, float]: 关键词权重字典
        """
        return {
            # 材料类型
            '合金': 2.0, 'alloy': 2.0, '钢': 1.8, 'steel': 1.8,
            '铝': 1.5, 'aluminum': 1.5, '镁': 1.5, 'magnesium': 1.5,
            '钛': 1.8, 'titanium': 1.8, '铜': 1.3, 'copper': 1.3,
            
            # 工艺参数
            '温度': 2.5, 'temperature': 2.5, '压力': 2.2, 'pressure': 2.2,
            '时间': 2.0, 'time': 2.0, '速度': 1.8, 'speed': 1.8,
            '热处理': 2.8, 'heat treatment': 2.8,
            '固溶': 2.5, 'solution': 2.5, '时效': 2.5, 'aging': 2.5,
            
            # 性能指标
            '硬度': 2.3, 'hardness': 2.3, '强度': 2.5, 'strength': 2.5,
            '韧性': 2.2, 'toughness': 2.2, '延伸率': 2.0, 'elongation': 2.0,
            '弹性模量': 2.1, 'elastic modulus': 2.1,
            
            # 微观结构
            '晶粒': 1.8, 'grain': 1.8, '相': 2.0, 'phase': 2.0,
            '析出': 1.9, 'precipitation': 1.9, '位错': 1.7, 'dislocation': 1.7,
            
            # 测试方法
            '拉伸': 1.5, 'tensile': 1.5, '压缩': 1.4, 'compression': 1.4,
            '疲劳': 1.6, 'fatigue': 1.6, '冲击': 1.5, 'impact': 1.5
        }
    
    def add_sample(self, sample: Dict[str, Any], importance_score: Optional[float] = None) -> None:
        """
        添加样本到回放缓冲区
        
        Args:
            sample: 样本数据
            importance_score: 重要性分数（可选）
        """
        # 计算语义嵌入
        semantic_embedding = self._compute_semantic_embedding(sample)
        
        # 计算重要性分数
        if importance_score is None:
            importance_score = self._compute_importance_score(sample)
        
        # 更新统计信息
        self._update_statistics(sample)
        
        # 添加到缓冲区
        sample_data = {
            'sample': sample,
            'semantic_embedding': semantic_embedding,
            'importance_score': importance_score,
            'timestamp': len(self.buffer)
        }
        
        self.buffer.append(sample_data)
        self.semantic_embeddings.append(semantic_embedding)
        self.importance_scores.append(importance_score)
        
        # 如果超出容量，移除最旧的样本
        if len(self.semantic_embeddings) > self.max_size:
            self.semantic_embeddings.pop(0)
            self.importance_scores.pop(0)
        
        self.replay_stats['total_added'] += 1
        
        print(f"添加样本到回放缓冲区，当前大小: {len(self.buffer)}")

    def score_sample(self, sample: Dict[str, Any]) -> float:
        """
        计算样本的重要性分数
        
        Args:
            sample: 样本数据
        
        Returns:
            float: 重要性分数
        """
        try:
            score = self._compute_importance_score(sample)
            return float(score)
        except Exception:
            return 0.1
    
    def _compute_semantic_embedding(self, sample: Dict[str, Any]) -> np.ndarray:
        """
        计算样本的语义嵌入
        
        Args:
            sample: 样本数据
            
        Returns:
            np.ndarray: 语义嵌入向量
        """
        # 提取文本内容
        text_content = self._extract_text_content(sample)
        
        # 如果TF-IDF未训练，先进行训练
        if not self.is_fitted:
            # 收集所有文本进行训练
            all_texts = [text_content]
            if len(self.buffer) > 0:
                all_texts.extend([self._extract_text_content(item['sample']) for item in self.buffer])
            
            if len(all_texts) > 1:
                self.tfidf_vectorizer.fit(all_texts)
                self.is_fitted = True
            else:
                # 如果只有一个样本，返回简单的特征向量
                return self._compute_simple_features(sample)
        
        try:
            # 计算TF-IDF向量
            tfidf_vector = self.tfidf_vectorizer.transform([text_content]).toarray()[0]
            
            # 添加领域特定特征
            domain_features = self._compute_domain_features(sample)
            
            # 合并特征
            combined_features = np.concatenate([tfidf_vector, domain_features])
            
            return combined_features
            
        except Exception as e:
            print(f"计算语义嵌入时出错: {e}")
            return self._compute_simple_features(sample)
    
    def _extract_text_content(self, sample: Dict[str, Any]) -> str:
        """
        从样本中提取文本内容
        
        Args:
            sample: 样本数据
            
        Returns:
            str: 提取的文本内容
        """
        text_parts = []
        
        # 提取主要文本
        if 'text' in sample:
            text_parts.append(str(sample['text']))
        
        # 提取三元组信息
        if 'spo_list' in sample:
            for triple in sample['spo_list']:
                if isinstance(triple, (list, tuple)) and len(triple) >= 3:
                    text_parts.extend([str(triple[0]), str(triple[1]), str(triple[2])])
                elif isinstance(triple, dict):
                    text_parts.extend([str(v) for v in triple.values()])
        
        # 提取其他文本字段
        for key, value in sample.items():
            if isinstance(value, str) and key not in ['text', 'spo_list']:
                text_parts.append(value)
        
        return ' '.join(text_parts)
    
    def _compute_domain_features(self, sample: Dict[str, Any]) -> np.ndarray:
        """
        计算材料领域特定特征
        
        Args:
            sample: 样本数据
            
        Returns:
            np.ndarray: 领域特征向量
        """
        features = []
        text_content = self._extract_text_content(sample).lower()
        
        # 关键词匹配特征
        keyword_scores = []
        for keyword, weight in self.domain_keywords.items():
            if keyword.lower() in text_content:
                keyword_scores.append(weight)
            else:
                keyword_scores.append(0.0)
        
        features.extend(keyword_scores)
        
        # 实体类型分布特征
        entity_type_features = self._compute_entity_type_features(sample)
        features.extend(entity_type_features)
        
        # 数值特征
        numerical_features = self._extract_numerical_features(text_content)
        features.extend(numerical_features)
        
        return np.array(features, dtype=np.float32)
    
    def _compute_entity_type_features(self, sample: Dict[str, Any]) -> List[float]:
        """
        计算实体类型特征
        
        Args:
            sample: 样本数据
            
        Returns:
            List[float]: 实体类型特征列表
        """
        entity_types = ['Element', 'Comp', 'Phase', 'Exp', 'Par_n', 'Par_v', 
                       'Test_n', 'Test_v', 'Property', 'Material']
        
        type_counts = {et: 0 for et in entity_types}
        
        if 'spo_list' in sample:
            for triple in sample['spo_list']:
                if isinstance(triple, (list, tuple)) and len(triple) >= 3:
                    head_type = self._classify_entity_type(str(triple[0]))
                    tail_type = self._classify_entity_type(str(triple[2]))
                    
                    if head_type in type_counts:
                        type_counts[head_type] += 1
                    if tail_type in type_counts:
                        type_counts[tail_type] += 1
        
        return list(type_counts.values())
    
    def _classify_entity_type(self, entity_text: str) -> str:
        """
        分类实体类型
        
        Args:
            entity_text: 实体文本
            
        Returns:
            str: 实体类型
        """
        entity_text = entity_text.lower()
        
        # 简化的实体类型分类
        if any(elem in entity_text for elem in ['al', 'mg', 'fe', 'cu', 'ni']):
            return 'Element'
        elif any(keyword in entity_text for keyword in ['合金', 'alloy', '成分']):
            return 'Comp'
        elif '相' in entity_text or 'phase' in entity_text:
            return 'Phase'
        elif any(keyword in entity_text for keyword in ['热处理', '固溶', '时效']):
            return 'Exp'
        elif any(keyword in entity_text for keyword in ['温度', '压力', '时间']):
            return 'Par_n'
        elif any(char.isdigit() for char in entity_text):
            return 'Par_v'
        else:
            return 'Material'
    
    def _extract_numerical_features(self, text: str) -> List[float]:
        """
        提取数值特征
        
        Args:
            text: 文本内容
            
        Returns:
            List[float]: 数值特征列表
        """
        features = []
        
        # 数字密度
        digit_count = sum(1 for char in text if char.isdigit())
        features.append(digit_count / max(len(text), 1))
        
        # 单位密度
        units = ['°c', 'mpa', 'gpa', 'hv', 'mm', 'cm', 'h', 'min', 's', '%']
        unit_count = sum(1 for unit in units if unit in text.lower())
        features.append(unit_count)
        
        # 符号密度
        symbols = ['+', '-', '=', '>', '<', '±']
        symbol_count = sum(1 for symbol in symbols if symbol in text)
        features.append(symbol_count)
        
        return features
    
    def _compute_simple_features(self, sample: Dict[str, Any]) -> np.ndarray:
        """
        计算简单特征（当TF-IDF不可用时）
        
        Args:
            sample: 样本数据
            
        Returns:
            np.ndarray: 简单特征向量
        """
        text_content = self._extract_text_content(sample)
        
        features = [
            len(text_content),  # 文本长度
            text_content.count(' '),  # 词数估计
            sum(1 for char in text_content if char.isdigit()),  # 数字数量
            len(sample.get('spo_list', [])),  # 三元组数量
        ]
        
        # 添加领域特征
        domain_features = self._compute_domain_features(sample)
        features.extend(domain_features.tolist())
        
        return np.array(features, dtype=np.float32)
    
    def _compute_importance_score(self, sample: Dict[str, Any]) -> float:
        """
        计算样本重要性分数
        
        Args:
            sample: 样本数据
            
        Returns:
            float: 重要性分数
        """
        score = 0.0
        text_content = self._extract_text_content(sample).lower()
        
        # 关键词重要性
        for keyword, weight in self.domain_keywords.items():
            if keyword.lower() in text_content:
                score += weight
        
        # 三元组数量重要性
        triple_count = len(sample.get('spo_list', []))
        score += triple_count * 0.5
        
        # 稀有实体类型重要性
        entity_types = set()
        if 'spo_list' in sample:
            for triple in sample['spo_list']:
                if isinstance(triple, (list, tuple)) and len(triple) >= 3:
                    entity_types.add(self._classify_entity_type(str(triple[0])))
                    entity_types.add(self._classify_entity_type(str(triple[2])))
        
        # 稀有类型加分
        for entity_type in entity_types:
            if self.entity_type_counts[entity_type] < 10:  # 稀有类型
                score += 1.0
        
        return max(score, 0.1)  # 最小分数
    
    def _update_statistics(self, sample: Dict[str, Any]) -> None:
        """
        更新统计信息
        
        Args:
            sample: 样本数据
        """
        if 'spo_list' in sample:
            for triple in sample['spo_list']:
                if isinstance(triple, (list, tuple)) and len(triple) >= 3:
                    head_type = self._classify_entity_type(str(triple[0]))
                    tail_type = self._classify_entity_type(str(triple[2]))
                    relation = str(triple[1])
                    
                    self.entity_type_counts[head_type] += 1
                    self.entity_type_counts[tail_type] += 1
                    self.relation_type_counts[relation] += 1
    
    def sample_for_replay(self, current_sample: Dict[str, Any], 
                         replay_size: int = 32) -> List[Dict[str, Any]]:
        """
        为回放选择样本
        
        Args:
            current_sample: 当前样本
            replay_size: 回放样本数量
            
        Returns:
            List[Dict[str, Any]]: 选择的回放样本
        """
        if len(self.buffer) == 0:
            return []
        
        replay_size = min(replay_size, len(self.buffer))
        
        # 计算当前样本的语义嵌入
        current_embedding = self._compute_semantic_embedding(current_sample)
        
        # 计算相似性分数
        similarity_scores = []
        for i, item in enumerate(self.buffer):
            similarity = self._compute_similarity(current_embedding, item['semantic_embedding'])
            similarity_scores.append((i, similarity, item['importance_score']))
        
        # 选择策略：结合语义相似性、重要性和多样性
        selected_samples = self._select_diverse_samples(
            similarity_scores, replay_size, current_embedding
        )
        
        self.replay_stats['total_replayed'] += len(selected_samples)
        
        print(f"选择了 {len(selected_samples)} 个回放样本")
        return selected_samples
    
    def _compute_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        计算两个嵌入向量的相似性
        
        Args:
            embedding1: 嵌入向量1
            embedding2: 嵌入向量2
            
        Returns:
            float: 相似性分数
        """
        try:
            # 确保向量长度一致
            min_len = min(len(embedding1), len(embedding2))
            emb1 = embedding1[:min_len].reshape(1, -1)
            emb2 = embedding2[:min_len].reshape(1, -1)
            
            # 计算余弦相似性
            similarity = cosine_similarity(emb1, emb2)[0, 0]
            return float(similarity)
            
        except Exception as e:
            print(f"计算相似性时出错: {e}")
            return 0.0
    
    def _select_diverse_samples(self, similarity_scores: List[Tuple[int, float, float]], 
                               replay_size: int, current_embedding: np.ndarray) -> List[Dict[str, Any]]:
        """
        选择多样化的样本
        
        Args:
            similarity_scores: 相似性分数列表
            replay_size: 回放大小
            current_embedding: 当前样本嵌入
            
        Returns:
            List[Dict[str, Any]]: 选择的样本
        """
        selected_indices = set()
        selected_samples = []
        
        # 按重要性和相似性排序
        similarity_scores.sort(key=lambda x: (x[2], x[1]), reverse=True)
        
        for idx, similarity, importance in similarity_scores:
            if len(selected_samples) >= replay_size:
                break
            
            if idx in selected_indices:
                continue
            
            # 检查多样性
            if self._is_diverse_enough(idx, selected_indices, current_embedding):
                selected_indices.add(idx)
                selected_samples.append(self.buffer[idx]['sample'])
                
                if similarity > self.semantic_threshold:
                    self.replay_stats['semantic_matches'] += 1
                else:
                    self.replay_stats['diversity_selections'] += 1
        
        # 如果选择的样本不够，随机补充
        while len(selected_samples) < replay_size and len(selected_samples) < len(self.buffer):
            remaining_indices = [i for i in range(len(self.buffer)) if i not in selected_indices]
            if not remaining_indices:
                break
            
            random_idx = random.choice(remaining_indices)
            selected_indices.add(random_idx)
            selected_samples.append(self.buffer[random_idx]['sample'])
        
        return selected_samples
    
    def _is_diverse_enough(self, candidate_idx: int, selected_indices: set, 
                          current_embedding: np.ndarray) -> bool:
        """
        检查候选样本是否足够多样化
        
        Args:
            candidate_idx: 候选样本索引
            selected_indices: 已选择的样本索引
            current_embedding: 当前样本嵌入
            
        Returns:
            bool: 是否足够多样化
        """
        if not selected_indices:
            return True
        
        candidate_embedding = self.buffer[candidate_idx]['semantic_embedding']
        
        # 检查与已选择样本的相似性
        for selected_idx in selected_indices:
            selected_embedding = self.buffer[selected_idx]['semantic_embedding']
            similarity = self._compute_similarity(candidate_embedding, selected_embedding)
            
            if similarity > 0.9:  # 太相似
                return False
        
        return True
    
    def get_all_samples(self) -> List[Dict[str, Any]]:
        """
        获取缓冲区中的所有样本
        
        Returns:
            List[Dict[str, Any]]: 缓冲区中的所有样本
        """
        return [item['sample'] for item in self.buffer]
    
    def get_buffer_statistics(self) -> Dict[str, Any]:
        """
        获取缓冲区统计信息
        
        Returns:
            Dict[str, Any]: 统计信息
        """
        stats = {
            'buffer_size': len(self.buffer),
            'max_size': self.max_size,
            'entity_type_counts': dict(self.entity_type_counts),
            'relation_type_counts': dict(self.relation_type_counts),
            'replay_stats': self.replay_stats.copy(),
            'avg_importance': np.mean(self.importance_scores) if self.importance_scores else 0.0,
            'is_fitted': self.is_fitted
        }
        
        return stats
    
    def save_buffer(self, filepath: str) -> None:
        """
        保存缓冲区状态
        
        Args:
            filepath: 保存路径
        """
        try:
            state = {
                'buffer': list(self.buffer),
                'semantic_embeddings': self.semantic_embeddings,
                'importance_scores': self.importance_scores,
                'entity_type_counts': dict(self.entity_type_counts),
                'relation_type_counts': dict(self.relation_type_counts),
                'replay_stats': self.replay_stats,
                'tfidf_vectorizer': self.tfidf_vectorizer if self.is_fitted else None,
                'is_fitted': self.is_fitted,
                'config': {
                    'max_size': self.max_size,
                    'semantic_threshold': self.semantic_threshold,
                    'diversity_weight': self.diversity_weight,
                    'importance_weight': self.importance_weight
                }
            }
            
            with open(filepath, 'wb') as f:
                pickle.dump(state, f)
            
            print(f"缓冲区状态已保存到: {filepath}")
            
        except Exception as e:
            print(f"保存缓冲区状态失败: {e}")
    
    def load_buffer(self, filepath: str) -> None:
        """
        加载缓冲区状态
        
        Args:
            filepath: 加载路径
        """
        try:
            with open(filepath, 'rb') as f:
                state = pickle.load(f)
            
            self.buffer = deque(state['buffer'], maxlen=self.max_size)
            self.semantic_embeddings = state['semantic_embeddings']
            self.importance_scores = state['importance_scores']
            self.entity_type_counts = defaultdict(int, state['entity_type_counts'])
            self.relation_type_counts = defaultdict(int, state['relation_type_counts'])
            self.replay_stats = state['replay_stats']
            
            if state['tfidf_vectorizer'] is not None:
                self.tfidf_vectorizer = state['tfidf_vectorizer']
                self.is_fitted = state['is_fitted']
            
            # 更新配置
            config = state.get('config', {})
            self.max_size = config.get('max_size', self.max_size)
            self.semantic_threshold = config.get('semantic_threshold', self.semantic_threshold)
            self.diversity_weight = config.get('diversity_weight', self.diversity_weight)
            self.importance_weight = config.get('importance_weight', self.importance_weight)
            
            print(f"缓冲区状态已从 {filepath} 加载")
            
        except Exception as e:
            print(f"加载缓冲区状态失败: {e}")


if __name__ == "__main__":
    # 测试代码
    print("测试语义回放缓冲区...")
    
    # 创建回放缓冲区
    replay_buffer = SemanticReplayBuffer(max_size=100)
    
    # 测试样本
    test_samples = [
        {
            'text': '铝合金在500°C下进行固溶处理，硬度达到150HV',
            'spo_list': [
                ['铝合金', 'Exp-Par_v', '500°C'],
                ['固溶处理', 'Test_v-Property', '150HV']
            ]
        },
        {
            'text': 'Mg2Si相在时效过程中析出，提高了合金强度',
            'spo_list': [
                ['Mg2Si相', 'Exp-Property', '时效'],
                ['合金强度', 'Property-Test_v', '提高']
            ]
        },
        {
            'text': '钛合金经过热处理后，拉伸强度为800MPa',
            'spo_list': [
                ['钛合金', 'Exp-Test_v', '热处理'],
                ['拉伸强度', 'Test_v-Par_v', '800MPa']
            ]
        }
    ]
    
    # 添加样本到缓冲区
    for sample in test_samples:
        replay_buffer.add_sample(sample)
    
    # 测试回放选择
    current_sample = {
        'text': '铝镁合金在450°C固溶处理，硬度测试结果为140HV',
        'spo_list': [
            ['铝镁合金', 'Exp-Par_v', '450°C'],
            ['硬度测试', 'Test_v-Property', '140HV']
        ]
    }
    
    replay_samples = replay_buffer.sample_for_replay(current_sample, replay_size=2)
    
    print(f"\n选择的回放样本数量: {len(replay_samples)}")
    for i, sample in enumerate(replay_samples):
        print(f"回放样本 {i+1}: {sample['text']}")
    
    # 获取统计信息
    stats = replay_buffer.get_buffer_statistics()
    print("\n缓冲区统计信息:")
    for key, value in stats.items():
        print(f"{key}: {value}")
