import torch
import torch.nn as nn
import torch.nn.functional as F
import re
from typing import Dict, List, Tuple, Any, Optional
import numpy as np


class ProcessParamConstraint(nn.Module):
    """
    工艺参数约束模块
    对材料工艺参数进行物理约束验证（如温度、压力范围等）
    """
    
    def __init__(self, valid_ranges: Dict[str, Dict[str, Tuple[float, float]]]):
        """
        初始化工艺参数约束
        
        Args:
            valid_ranges: 有效参数范围字典
                格式: {"relation_type": {"param_type": (min_val, max_val)}}
        """
        super(ProcessParamConstraint, self).__init__()
        self.valid_ranges = valid_ranges
        self.param_patterns = {
            "温度": [r'(\d+(?:\.\d+)?)\s*[°℃]?\s*C', r'(\d+(?:\.\d+)?)\s*K', r'温度.*?(\d+(?:\.\d+)?)'],
            "压力": [r'(\d+(?:\.\d+)?)\s*[Mm]?[Pp]a', r'压力.*?(\d+(?:\.\d+)?)'],
            "时间": [r'(\d+(?:\.\d+)?)\s*[hH小时]', r'(\d+(?:\.\d+)?)\s*min', r'时间.*?(\d+(?:\.\d+)?)'],
            "速度": [r'(\d+(?:\.\d+)?)\s*mm/min', r'速度.*?(\d+(?:\.\d+)?)'],
        }
    
    def detect_parameter_type(self, text: str) -> Optional[str]:
        """
        检测参数类型
        
        Args:
            text: 输入文本
            
        Returns:
            Optional[str]: 检测到的参数类型
        """
        text = text.lower()
        
        if any(keyword in text for keyword in ['温度', '°c', '℃', 'temperature']):
            return "温度"
        elif any(keyword in text for keyword in ['压力', 'mpa', 'pressure']):
            return "压力"
        elif any(keyword in text for keyword in ['时间', 'time', 'h', 'min']):
            return "时间"
        elif any(keyword in text for keyword in ['速度', 'speed', 'mm/min']):
            return "速度"
        
        return None
    
    def extract_numeric_values(self, text: str, param_type: str) -> List[float]:
        """
        从文本中提取数值
        
        Args:
            text: 输入文本
            param_type: 参数类型
            
        Returns:
            List[float]: 提取的数值列表
        """
        values = []
        patterns = self.param_patterns.get(param_type, [])
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                try:
                    values.append(float(match))
                except ValueError:
                    continue
        
        return values
    
    def forward(self, relation: str, tail_entities: str) -> torch.Tensor:
        """
        前向传播，计算约束掩码
        
        Args:
            relation: 关系类型
            tail_entities: 尾实体文本
            
        Returns:
            torch.Tensor: 约束掩码张量
        """
        if relation == "Exp-Par_v" or relation == "Par_n-Par_v":
            param_type = self.detect_parameter_type(tail_entities)
            if param_type and param_type in self.valid_ranges.get(relation, {}):
                min_val, max_val = self.valid_ranges[relation][param_type]
                values = self.extract_numeric_values(tail_entities, param_type)
                
                if values:
                    # 检查是否有值超出范围
                    invalid_values = [v for v in values if v < min_val or v > max_val]
                    if invalid_values:
                        return torch.tensor(-1e9, dtype=torch.float32)  # 施加强惩罚
        
        return torch.tensor(0.0, dtype=torch.float32)


class PerformanceCorrelationConstraint(nn.Module):
    """
    性能相关性约束模块
    验证材料性能指标之间的物理相关性
    """
    
    def __init__(self, correlation_rules: Dict[Tuple[str, str], str]):
        """
        初始化性能相关性约束
        
        Args:
            correlation_rules: 相关性规则字典
                格式: {("metric1", "metric2"): "correlation_type"}
        """
        super(PerformanceCorrelationConstraint, self).__init__()
        self.correlation_rules = correlation_rules
        self.performance_keywords = {
            "硬度": ["硬度", "hardness", "hv", "hb", "hrc"],
            "延伸率": ["延伸率", "伸长率", "elongation", "延展性"],
            "强度": ["强度", "strength", "抗拉强度", "屈服强度"],
            "韧性": ["韧性", "toughness", "冲击韧性"],
            "导电性": ["导电", "电导率", "conductivity"],
            "热膨胀": ["热膨胀", "膨胀系数", "thermal expansion"]
        }
    
    def detect_performance_type(self, text: str) -> Optional[str]:
        """
        检测性能类型
        
        Args:
            text: 输入文本
            
        Returns:
            Optional[str]: 检测到的性能类型
        """
        text = text.lower()
        
        for perf_type, keywords in self.performance_keywords.items():
            if any(keyword in text for keyword in keywords):
                return perf_type
        
        return None
    
    def detect_trend(self, text1: str, text2: str) -> str:
        """
        检测性能变化趋势
        
        Args:
            text1: 第一个性能文本
            text2: 第二个性能文本
            
        Returns:
            str: 变化趋势（"正相关", "负相关", "无关"）
        """
        # 检测增减关键词
        increase_keywords = ["提高", "增加", "上升", "改善", "增强"]
        decrease_keywords = ["降低", "减少", "下降", "恶化", "减弱"]
        
        text1_trend = None
        text2_trend = None
        
        for keyword in increase_keywords:
            if keyword in text1:
                text1_trend = "增加"
            if keyword in text2:
                text2_trend = "增加"
        
        for keyword in decrease_keywords:
            if keyword in text1:
                text1_trend = "减少"
            if keyword in text2:
                text2_trend = "减少"
        
        if text1_trend == text2_trend and text1_trend is not None:
            return "正相关"
        elif text1_trend != text2_trend and text1_trend is not None and text2_trend is not None:
            return "负相关"
        else:
            return "无关"
    
    def forward(self, head_entity: str, tail_entity: str, relation: str) -> torch.Tensor:
        """
        前向传播，计算相关性约束
        
        Args:
            head_entity: 头实体文本
            tail_entity: 尾实体文本
            relation: 关系类型
            
        Returns:
            torch.Tensor: 约束掩码张量
        """
        if relation == "Test_n-Test_v" or relation == "Property-Value":
            head_type = self.detect_performance_type(head_entity)
            tail_type = self.detect_performance_type(tail_entity)
            
            if head_type and tail_type:
                metric_pair = (head_type, tail_type)
                reverse_pair = (tail_type, head_type)
                
                expected_correlation = None
                if metric_pair in self.correlation_rules:
                    expected_correlation = self.correlation_rules[metric_pair]
                elif reverse_pair in self.correlation_rules:
                    expected_correlation = self.correlation_rules[reverse_pair]
                
                if expected_correlation:
                    actual_trend = self.detect_trend(head_entity, tail_entity)
                    if actual_trend != expected_correlation and actual_trend != "无关":
                        return torch.tensor(-1e9, dtype=torch.float32)  # 施加惩罚
        
        return torch.tensor(0.0, dtype=torch.float32)


class PhaseCompositionConstraint(nn.Module):
    """
    相组成约束模块
    验证材料相组成的化学计量比
    """
    
    def __init__(self, phase_ratios: Dict[str, Dict[str, int]]):
        """
        初始化相组成约束
        
        Args:
            phase_ratios: 相组成比例字典
                格式: {"phase_name": {"element": ratio}}
        """
        super(PhaseCompositionConstraint, self).__init__()
        self.phase_ratios = phase_ratios
        self.element_patterns = {
            "Al": [r'Al\s*(\d*(?:\.\d+)?)', r'铝\s*(\d*(?:\.\d+)?)', r'aluminum\s*(\d*(?:\.\d+)?)'],
            "Mg": [r'Mg\s*(\d*(?:\.\d+)?)', r'镁\s*(\d*(?:\.\d+)?)', r'magnesium\s*(\d*(?:\.\d+)?)'],
            "Si": [r'Si\s*(\d*(?:\.\d+)?)', r'硅\s*(\d*(?:\.\d+)?)', r'silicon\s*(\d*(?:\.\d+)?)'],
            "Ni": [r'Ni\s*(\d*(?:\.\d+)?)', r'镍\s*(\d*(?:\.\d+)?)', r'nickel\s*(\d*(?:\.\d+)?)'],
            "Fe": [r'Fe\s*(\d*(?:\.\d+)?)', r'铁\s*(\d*(?:\.\d+)?)', r'iron\s*(\d*(?:\.\d+)?)'],
        }
    
    def detect_phase(self, text: str) -> Optional[str]:
        """
        检测相类型
        
        Args:
            text: 输入文本
            
        Returns:
            Optional[str]: 检测到的相类型
        """
        text = text.upper()
        
        # 常见金属间化合物相
        phase_patterns = {
            "Mg2Si": [r'Mg2Si', r'Mg₂Si'],
            "Al3Ni": [r'Al3Ni', r'Al₃Ni'],
            "Fe3C": [r'Fe3C', r'Fe₃C'],
            "Al2Cu": [r'Al2Cu', r'Al₂Cu'],
        }
        
        for phase_name, patterns in phase_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text):
                    return phase_name
        
        return None
    
    def calculate_element_ratio(self, text: str) -> Dict[str, float]:
        """
        计算元素比例
        
        Args:
            text: 输入文本
            
        Returns:
            Dict[str, float]: 元素比例字典
        """
        ratios = {}
        
        for element, patterns in self.element_patterns.items():
            for pattern in patterns:
                matches = re.findall(pattern, text)
                if matches:
                    try:
                        # 如果没有明确数字，默认为1
                        ratio = float(matches[0]) if matches[0] else 1.0
                        ratios[element] = ratio
                        break
                    except ValueError:
                        continue
        
        return ratios
    
    def match_ratio(self, actual_ratio: Dict[str, float], 
                   required_ratio: Dict[str, int], tolerance: float = 0.1) -> bool:
        """
        匹配元素比例
        
        Args:
            actual_ratio: 实际比例
            required_ratio: 要求比例
            tolerance: 容差范围
            
        Returns:
            bool: 是否匹配
        """
        if not actual_ratio or not required_ratio:
            return False
        
        # 归一化比例
        actual_total = sum(actual_ratio.values())
        required_total = sum(required_ratio.values())
        
        if actual_total == 0 or required_total == 0:
            return False
        
        for element, required_val in required_ratio.items():
            if element not in actual_ratio:
                return False
            
            actual_normalized = actual_ratio[element] / actual_total
            required_normalized = required_val / required_total
            
            if abs(actual_normalized - required_normalized) > tolerance:
                return False
        
        return True
    
    def forward(self, relation: str, head_entities: str, tail_entities: str) -> torch.Tensor:
        """
        前向传播，计算相组成约束
        
        Args:
            relation: 关系类型
            head_entities: 头实体文本
            tail_entities: 尾实体文本
            
        Returns:
            torch.Tensor: 约束掩码张量
        """
        if relation == "Phase-Test_v" or relation == "Comp-Phase":
            phase_type = self.detect_phase(head_entities)
            if phase_type and phase_type in self.phase_ratios:
                required_ratio = self.phase_ratios[phase_type]
                actual_ratio = self.calculate_element_ratio(tail_entities)
                
                if not self.match_ratio(actual_ratio, required_ratio):
                    return torch.tensor(-1e9, dtype=torch.float32)  # 非法相组成
        
        return torch.tensor(0.0, dtype=torch.float32)


class MaterialConstraintAttention(nn.Module):
    """
    材料约束注意力模块
    整合多种材料物理约束，用于三元组解码过程中的约束验证
    """
    
    def __init__(self, constraints: Dict[str, Any]):
        """
        初始化材料约束注意力模块
        
        Args:
            constraints: 约束配置字典
        """
        super(MaterialConstraintAttention, self).__init__()
        
        self.process_constraint = ProcessParamConstraint(
            constraints.get("process_ranges", {})
        )
        self.performance_constraint = PerformanceCorrelationConstraint(
            constraints.get("correlation_rules", {})
        )
        self.phase_constraint = PhaseCompositionConstraint(
            constraints.get("phase_ratios", {})
        )
        
        # 约束权重
        self.constraint_weights = constraints.get("weights", {
            "process": 1.0,
            "performance": 1.0,
            "phase": 1.0
        })
    
    def forward(self, relation: str, head: str, tail: str) -> torch.Tensor:
        """
        前向传播，计算综合约束掩码
        
        Args:
            relation: 关系类型
            head: 头实体文本
            tail: 尾实体文本
            
        Returns:
            torch.Tensor: 综合约束掩码
        """
        mask = torch.tensor(0.0, dtype=torch.float32)
        
        # 工艺参数约束
        process_mask = self.process_constraint(relation, tail)
        mask += self.constraint_weights["process"] * process_mask
        
        # 性能相关性约束
        performance_mask = self.performance_constraint(head, tail, relation)
        mask += self.constraint_weights["performance"] * performance_mask
        
        # 相组成约束
        phase_mask = self.phase_constraint(relation, head, tail)
        mask += self.constraint_weights["phase"] * phase_mask
        
        return mask
    
    def get_constraint_info(self) -> Dict[str, Any]:
        """
        获取约束信息
        
        Returns:
            Dict[str, Any]: 约束配置信息
        """
        return {
            "process_ranges": self.process_constraint.valid_ranges,
            "correlation_rules": self.performance_constraint.correlation_rules,
            "phase_ratios": self.phase_constraint.phase_ratios,
            "weights": self.constraint_weights
        }


def create_default_material_constraints() -> Dict[str, Any]:
    """
    创建默认的材料约束配置
    
    Returns:
        Dict[str, Any]: 默认约束配置
    """
    return {
        "process_ranges": {
            "Exp-Par_v": {
                "温度": (0, 1200),  # 0-1200°C
                "压力": (0.1, 500),  # 0.1-500 MPa
                "时间": (0.1, 100),  # 0.1-100 小时
                "速度": (0.1, 1000)  # 0.1-1000 mm/min
            },
            "Par_n-Par_v": {
                "温度": (0, 1200),
                "压力": (0.1, 500),
                "时间": (0.1, 100),
                "速度": (0.1, 1000)
            }
        },
        "correlation_rules": {
            ("硬度", "延伸率"): "负相关",
            ("强度", "韧性"): "负相关",
            ("温度", "热膨胀"): "正相关",
            ("硬度", "强度"): "正相关"
        },
        "phase_ratios": {
            "Mg2Si": {"Mg": 2, "Si": 1},
            "Al3Ni": {"Al": 3, "Ni": 1},
            "Fe3C": {"Fe": 3, "C": 1},
            "Al2Cu": {"Al": 2, "Cu": 1}
        },
        "weights": {
            "process": 1.0,
            "performance": 0.8,
            "phase": 1.2
        }
    }


if __name__ == "__main__":
    # 测试代码
    constraints = create_default_material_constraints()
    mca = MaterialConstraintAttention(constraints)
    
    # 测试工艺参数约束
    print("测试工艺参数约束:")
    mask1 = mca("Exp-Par_v", "固溶处理", "在800°C下进行")
    print(f"800°C固溶处理约束掩码: {mask1}")
    
    # 测试性能相关性约束
    print("\n测试性能相关性约束:")
    mask2 = mca("Test_n-Test_v", "硬度提高", "延伸率显著增加")
    print(f"硬度-延伸率约束掩码: {mask2}")
    
    # 测试相组成约束
    print("\n测试相组成约束:")
    mask3 = mca("Phase-Test_v", "Mg2Si相", "Mg含量1wt%，Si含量3wt%")
    print(f"Mg2Si相组成约束掩码: {mask3}")